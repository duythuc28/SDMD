# Module6-Tasks

This folder contains code for assessment tasks in module 6, namely the movie
ratings app code.
